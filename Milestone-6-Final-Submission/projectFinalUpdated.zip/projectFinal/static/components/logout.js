const logout = {

    data() {
      return {
      }
    },
  
    created() {
        console.log('Logging out..')
          localStorage.clear()
          this.$router.push('/')
    },
  }
  
  export default logout
  