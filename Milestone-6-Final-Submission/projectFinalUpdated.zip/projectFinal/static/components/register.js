const register = {
    template: `
    <section class="vh-100">
  <div class="container-fluid">
    <nav class="navbar navbar-light bg-light">
      <h2>Support System</h2>
      <i>Query your doubts</i>
    </nav>
    <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Register</h3>
          <form action=''>
            <div class="mb-3">
              <label for="username" class="form-label">Username</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="username" name="username" minlength="4" v-model="formData.username" required>
                </div>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="email" name="email" minlength="4" v-model="formData.email" required>
                </div>
            </div>
            <div class="mb-3">
              <label for="password" class="form-label">Password</label>
                <div class="col-sm-10">
                  <input type="password" class="form-control" id="password" name="password" minlength="4" v-model="formData.password" required>
                </div>
            </div>
            <div class="mb-3">
              <label for="registerType" class="form-label">TypeOf</label>
               <div class="col-sm-10">
                  <select class="form-select" aria-label="Default select example" id = "registerType" name="registerType" v-model="formData.registerType" @change="changeEvent($event)">
                    <option selected value="Student">Student</option>
                    <option value="Lecturer">Lecturer</option>
                  </select>
              </div>
            </div>
            <div class="mb-3" id="subjects_div" style="display:none;">
              <label for="subjects" class="form-label">Subjects</label>
               <div class="col-sm-10">
                <div v-if="formData.message != 'None'">
                  <select class="form-select" aria-label="Default select example" id = "value" name="value" v-model="formData.subject_id">
                    <option v-for="subject in formData.subject_list" v-bind:value="subject.subject_id"selected >{{subject.subject_name}}</option>
                  </select>
                  </div>
              </div>
            </div>
            <button type="submit" class="btn btn-primary" @click.prevent="registerUser">Submit</button>
          </form>
          <p>Already have an account? <router-link to="/">Login here</router-link></p>

      </div>
    </div>
  </div>
</section>
    `,
  
    data() {
      return {
        formData: {
          username:'',
          email: '',
          password: '',
          registerType: '',
          subject_list: [],
          message: '',
          subject_id:''
        },
      }
    },
    async mounted () {
      document.title = 'Register Page'
      const res = await fetch('/api/register', {
          method: 'get',
          headers: {
            'Content-Type': 'application/json',
          }
        })
        console.log(res)
        const data = await res.json()
        console.log(data)
        if (res.ok){
            this.formData.message = data.message
            if(this.formData.message != 'None'){
                this.formData.subject_list = data.subject_list
            }
            
        }
        else{
          this.$toastr.error('ERROR',data.error_message,{
            positionClass: 'toast-top-center'
        });
        this.$router.push('/dashboard')
        }
    },
    methods: {
      changeEvent(el) {
            var x = el.target.value;
            if (x == "Lecturer") {
              document.getElementById('subjects_div').style.display = 'block';
            }
            else{
              document.getElementById('subjects_div').style.display = 'none';
            } 
          },
      async registerUser() {
         console.log(this.formData)
        const res = await fetch('/api/register', {
          method: 'post',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(this.formData),
        })
        console.log(res)
        const data = await res.json()
        console.log(data)
        if (res.ok) {
          const result = await fetch('/login?include_auth_token', {
            method: 'post',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({'email':this.formData.email,'password':this.formData.password}),
          })
          console.log(result)
          if (result.ok) {
            const data1 = await result.json()
            localStorage.setItem(
              'auth-token',
              data1.response.user.authentication_token
            )
            localStorage.setItem(
              'isAuthenticated',
              'true'
            )
            let checkres = await fetch('/api/checktype', {
            headers: {
              'Content-Type': 'application/json',
              'Authentication-Token': localStorage.getItem('auth-token'),
            },
            })
            let checkdata = await checkres.json()
            console.log(checkdata.username, checkdata.typeOf)
            if (checkres.ok){
              if(checkdata.typeOf == 'admin'){
                localStorage.setItem(
                'isType',
                'Admin'
                )
                this.$router.push('/admin/dashboard')
              }
              else if (checkdata.typeOf == 'Student'){
                localStorage.setItem(
                'isType',
                'Student'
                )
                this.$router.push('/student/dashboard')
              }
              else{
                localStorage.setItem(
                'isType',
                'Teacher'
                )
                this.$router.push('/teacher/dashboard')
              }
            }
          } else {
            console.log('Not able to authenticate')
          }
          } else {
            console.log(data.error_message)
          this.$toastr.error('Registration Failed',data.error_message,{
            positionClass: 'toast-top-center'
        });
        }
      },
    },
  }

  export default register  