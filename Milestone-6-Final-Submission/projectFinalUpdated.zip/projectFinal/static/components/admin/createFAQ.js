const createFAQ = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
       <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/admin/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Welcome {{ username }} </h3>
      <br>
          <h5>Add FAQ Details</h5>
          <br><br>
          <form action =''>
            <div class="mb-3">
              <label for="subject_name" class="form-label">FAQ Title</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="faq_title" name="faq_title" v-model ="faq_title" required>
              </div>
              </div>
            <div class="mb-3">
              <label for="subject_name" class="form-label">FAQ Answer</label>
               <div class="col-sm-10">
                  <textarea class="form-control" id="faq_ans" rows="4" name="faq_ans" required v-model="faq_ans"></textarea>
              </div>
              </div>
            <div class="mb-3" id="subjects_div">
              <label for="subjects" class="form-label">Subjects</label>
               <div class="col-sm-10">
                <div v-if="message != 'None'">
                  <select class="form-select" aria-label="Default select example" id = "value" name="value" v-model="subject_id">
                    <option v-for="subject in subject_list" v-bind:value="subject.subject_id"selected >{{subject.subject_name}}</option>
                  </select>
                  </div>
              </div>
            </div>
            <button type="submit" class="btn btn-primary" @click.prevent="addFAQ">Submit</button>
          </form>
      </div>
    </div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        faq_title:'',
        faq_ans:'',
        message:'',
        subject_list:[],
        subject_id:''
      }
    },
    async mounted () {
      document.title = 'Create FAQ'
      const res = await fetch('/api/admin/createFAQ', {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.message = data.message
        if(this.message !='None'){
          this.subject_list = data.subject_list
        }
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      this.$router.push('/admin/dashboard')
      }

    },
  
    methods: {
          async addFAQ(){
              if(this.faq_title == ''){
                this.$toastr.error('FAQ Title Required','',{
                  positionClass: 'toast-top-center'
              });
              }
              else if(this.faq_ans == ''){
                this.$toastr.error('FAQ Ans Required','',{
                  positionClass: 'toast-top-center'
              });
              }
              else if(this.subject_id == ''){
                this.$toastr.error('Subject Required','',{
                  positionClass: 'toast-top-center'
              });
              }
              else{
            const res = await fetch('/api/admin/createFAQ', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth-token'),
                  },
                body: JSON.stringify({'faq_title':this.faq_title,'faq_ans':this.faq_ans,'subject_id':this.subject_id}),
              })
              console.log(res)
              const data = await res.json()
              console.log(data)
              if (res.ok){
                this.$toastr.success('FAQ Added','',{
                    positionClass: 'toast-top-center'
                });
                this.$router.push('/admin/dashboard')
              }
              else{
                console.log(data.error_message)
                  this.$toastr.error('ERROR',data.error_message,{
                  positionClass: 'toast-top-center'
                });
              }
            }
          }

    },
  }
  
  export default createFAQ
  