const addsubject = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
       <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/admin/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Welcome {{ username }} </h3>
      <br>
          <h5>Add Subject Details</h5>
          <br><br>
          <form action =''>
            <div class="mb-3">
              <label for="subject_name" class="form-label">Course Name</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="subject_name" name="subject_name" v-model ="subject_name" required>
              </div>
              </div>
                  
            <button type="submit" class="btn btn-primary" @click.prevent="addSubject">Submit</button>
          </form>
      </div>
    </div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        subject_name:''
      }
    },
    async mounted () {
      document.title = 'Add Subject'
      const res = await fetch('/api/addsubject', {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      this.$router.push('/admin/dashboard')
      }
    },
  
    methods: {
          async addSubject(){
            const subjectsRe =/^[A-Za-z]+$/
            if(this.subject_name == ''){
                this.$toastr.error('Subject Name Required','',{
                  positionClass: 'toast-top-center'
              });
              }
              else if(!(subjectsRe.test(this.subject_name))){
                this.$toastr.error('Pattern Mismatch','Only String is allowed',{
                    positionClass: 'toast-top-center'
                  })
              }
              else{
            const res = await fetch('/api/addsubject', {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth-token'),
                  },
                body: JSON.stringify({'subject_name':this.subject_name}),
              })
              console.log(res)
              const data = await res.json()
              console.log(data)
              if (res.ok){
                this.$toastr.success('Subject Added','',{
                    positionClass: 'toast-top-center'
                });
                this.$router.push('/admin/dashboard')
              }
              else{
                console.log(data.error_message)
                  this.$toastr.error('ERROR',data.error_message,{
                  positionClass: 'toast-top-center'
                });
              }
            }
          }

    },
  }
  
  export default addsubject
  