const adminTicketsView = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
        <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/admin/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
		  <div class="col-sm-6 text-black center-block">
		  	<h3>Welcome {{ username }} </h3>
       
          <div v-if="message">
        <h5>Subject - {{  ticketList.subject_name  }}</h5>
        </div>
        <br>
        <br>
            <h6>Title - {{  ticketList.name  }}</h6>
            <br>
            <h6>Description - {{  ticketList.description  }}</h6>
            <br>
            <div v-if="comments">
            <h6><u>Comments</u></h6>
              <div v-for="comment in comments">
                <h6>{{ comment.user_name }} - {{  comment.user_type  }}</h6> 
                <br>
                <p><i>{{ comment.comment_desc }} </i></p>   
              </div>
            </div>

		  </div>
		</div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        ticketList:[],
        comments:[],
        message:''
      }
    },
    async mounted () {
      document.title = 'TicketsView'
      const res = await fetch(`/api/admin/viewTicket/${this.$route.params.ticket_id}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      console.log(res)
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.ticketList = data.ticket_list[0]
        this.comments = data.comments
        this.message = data.message
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      }
    },
  
    methods: {
      
    },

  }
  
  export default adminTicketsView
  