const adminDashboard = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
        <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/admin/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
		  <div class="col-sm-6 text-black center-block">
		  	<h3>Welcome {{ username }} </h3>
        <div v-if="message">
        <br><br>
        <table class="table table-hover">
          <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Count</th>
          </tr>
          </thead>
          <tbody>
          <tr v-if="message">
            <th scope="row">1</th>
            <td><router-link :to="'/admin/viewSubject'">Course List</router-link></td>
            <td>{{ subject_list_len }}</td>
            </tr>
             <tr v-if="countOfTickets">
            <th scope="row">2</th>
            <td>Total Tickets</td>
            <td>{{ countOfTickets }}</td>
            </tr>
             <tr v-if="closedTicket">
            <th scope="row">3</th>
            <td>Closed Ticket</td>
            <td>{{ closedTicket }}</td>
            </tr>
             <tr v-if="faqCount">
            <th scope="row">4</th>
            <td><router-link :to="'/admin/listFAQ'">FAQ Requested</router-link></td>
            <td>{{ faqCount }}</td>
            </tr>
          </tbody>
        </table>
        </div>
        <div v-else>
        <br><br>
        <h5 class="text-center"><i>You don't have any Subjects to view</i></h5>
        <br><br>
        </div>
		    <div class="col-md-12 text-center">
        <router-link to="/admin/addsubject"><button type="submit" class="btn btn-primary ">Add Subjects</button></router-link>
				</div>
		  </div>
		</div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        subject_list_len: '',
        message: '',
        countOfTickets:'',
        closedTicket:'',
        faqCount:''
      }
    },
    async mounted () {
      document.title = 'Dashboard'
      const res = await fetch('/api/admin/dashboard', {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      console.log(res)
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.subject_list_len = data.subject_list_len
        this.message = data.message
        this.countOfTickets = data.countOfTickets
        this.closedTicket = data.closedTicket
        this.faqCount= data.faqCount
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      }
    },
  
    methods: {
      
    },

  }
  
  export default adminDashboard
  