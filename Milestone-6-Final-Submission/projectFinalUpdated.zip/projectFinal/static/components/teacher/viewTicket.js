const viewTeacherTicket = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
        <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/teacher/dashboard">Home</router-link></h5></div>

      </div>

      <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Welcome {{ username }}</h3>
      <br>
      <div v-if="message">
        <h5>Subject - {{  subject_list.subject_name  }}</h5>
        </div>
        <br>
        <br>
            <h6>Title - {{  ticketList.name  }}</h6>
            <br>
            <h6>Description - {{  ticketList.description  }}</h6>
            <br>
            <div v-if="comments">
            <h6><u>Comments</u></h6>
              <div v-for="comment in comments">
                <h6>{{ comment.user_name }} - {{  comment.user_type  }}</h6> 
                <br>
                <p><i>{{ comment.comment_desc }} </i></p>   
              </div>
            </div>
            <div class="col-sm-10" v-if="enableComment">
                <textarea class="form-control" id="comment" rows="4" name="comment" required v-model="comment"></textarea>
                <br>
                <button type="submit" class="btn btn-primary" @click.prevent="addComment">Add Comment</button>
            </div>
      </div>
    </div>

    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        subject_list:[],
        message:'',
        ticketList:[],
        enableComment:false,
        comment:'',
        alreadyLiked:false,
        comments:[]
      }
    },
    async mounted () {
      document.title = 'View Ticket'
      const res = await fetch(`/api/teacher/viewTicket/${this.$route.params.subject_id}/${this.$route.params.ticket_id}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      console.log(res)
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.message = data.message
        this.subject_list = data.subject_list
        this.ticketList = data.ticket_list
        this.enableComment=data.enableComment
        this.comments = data.comments
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      this.$router.push('/teacher/dashboard')
      }
    },
  
    methods: {
         async addComment(){
            if(this.comment == ''){
                this.$toastr.error('Comment Required','',{
                  positionClass: 'toast-top-center'
              });
            }
            else{
            const res = await fetch(`/api/teacher/viewTicket/${this.$route.params.subject_id}/${this.$route.params.ticket_id}`, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth-token'),
                  },
                body: JSON.stringify({'comment':this.comment}),
              })
              console.log(res)
              const data = await res.json()
              console.log(data)
              if (res.ok){
                this.$toastr.success('Comment Added','',{
                    positionClass: 'toast-top-center'
                });
                this.$router.push('/teacher/dashboard')
              }
              else{
                console.log(data.error_message)
                  this.$toastr.error('ERROR',data.error_message,{
                  positionClass: 'toast-top-center'
                });
              }
            }
        },
    },
  }
  
  export default viewTeacherTicket
  