const teacherDashboard = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
        <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/teacher/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
		  <div class="col-sm-8 text-black center-block">
		  	<h3>Welcome {{ username }} </h3>
        <br>
        <div v-if="message">
        <h5>Subject - {{  subjectList.subject_name  }}</h5>
        </div>

        <div v-if="isTicket">
            <table class="table table-hover caption-top">
            <caption>Ticket Details</caption>
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Timestamp</th>
                  <th scope="col">Title</th>
                  <th scope="col">Status</th>
                  <th scope="col">Number of Likes</th>
                  <th scope="col">Add To FAQ</th>
                </tr>
              </thead>
              <tbody>
              <tr v-for="(x,index) in ticketList">
                <th scope="row">{{index+1}}</th>
                <td>{{x.timestamp}}</td>
                <td><router-link :to="'/teacher/viewTicket/' + subjectList.subject_id + '/' + x.ticket_id">{{x.name}}</router-link></td>
                <td>{{x.status}}</td>
                <td>{{x.count}}</td>
                <td v-if="!x.addedToFAQ"><button type="button" class="btn btn-link" @click.prevent="faqAddition(x.ticket_id)">AddToFAQ</button></td>
                <td v-if="x.addedToFAQ">FAQ request raised</td>
              </tr>
              </tbody>
            </table>
            </div>
            <div v-else>
            <br><br>
            <h5 class="text-center"><i>You don't have any tickets to view</i></h5>
            <br><br>
            </div>

		  </div>
		</div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        subjectList: [],
        isTicket : false,
        ticketList:[],
        message:''
      }
    },
    async mounted () {
      document.title = 'Dashboard'
      const res = await fetch('/api/teacher/dashboard', {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      console.log(res)
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.subjectList = data.subject_list[0]
        this.ticketList = data.tickets_list
        this.message = data.message
        this.isTicket = data.isTicket
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      }
    },
  
    methods: {
      
        async faqAddition(ticket_id){
            const res = await fetch('/api/teacher/faqAddition', {
              method: 'post',
              headers: {
                  'Content-Type': 'application/json',
                  'Authentication-Token': localStorage.getItem('auth-token'),
                },
              body: JSON.stringify({'ticket_id':ticket_id}),
            })
            console.log(res)
            const data = await res.json()
            console.log(data)
            if (res.ok){
              this.$toastr.success('FAQ Request Submitted','',{
                  positionClass: 'toast-top-center'
              });
              this.$router.go(this.$router.currentRoute)
            }
            else{
              console.log(data.error_message)
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      this.$router.go(this.$router.currentRoute)
            }
          },
    },

  }
  
  export default teacherDashboard