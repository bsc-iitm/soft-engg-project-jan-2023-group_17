const login = {
  template: `
  <section class="vh-100">
  <div class="container-fluid">
    <nav class="navbar navbar-light bg-light">
      <h2>Support System</h2>
      <i>Query your doubts</i>
    </nav>
    <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Login</h3>
        <form action=''>
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
            <div class="col-sm-10">
              <input type="email" class="form-control" id="email" name="email" v-model="formData.email" required>
            </div>
        </div>
        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
            <div class="col-sm-10">
              <input type="password" class="form-control" id="password" name="password" v-model="formData.password" required>
            </div>
        </div>
        <button type="submit" class="btn btn-primary" @click.prevent="loginUser">Submit</button>
      </form>
          <p>Don't have an account? <router-link to="/register">Register here</router-link></p>

      </div>
    </div>
  </div>
</section>
  `,

  data() {
    return {
      formData: {
        email: '',
        password: '',
      },
    }
  },
  mounted () {
    document.title = 'Login Page'
  },

  methods: {
    async loginUser() {
      if(this.formData.email == ''){
        this.$toastr.error('Email Required','',{
          positionClass: 'toast-top-center'
      });
      }
      else if(this.formData.password == ''){
        this.$toastr.error('Password Required','',{
          positionClass: 'toast-top-center'
      });
      }
      else{
      let res = await fetch('/login?include_auth_token', {
        method: 'post',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(this.formData),
      })

      if (res.ok) {
        let data = await res.json()
        localStorage.setItem(
          'auth-token',
          data.response.user.authentication_token
        )
        localStorage.setItem(
          'isAuthenticated',
          'true'
        )
        res = await fetch('/api/checktype', {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
          },
        })
        data = await res.json()
        console.log(data.username, data.typeOf)
        if (res.ok){
          if(data.typeOf == 'admin'){
            localStorage.setItem(
            'isType',
            'Admin'
            )
            this.$router.push('/admin/dashboard')
          }
          else if (data.typeOf == 'Student'){
            localStorage.setItem(
            'isType',
            'Student'
            )
            this.$router.push('/student/dashboard')
          }
          else{
            localStorage.setItem(
            'isType',
            'Teacher'
            )
            this.$router.push('/teacher/dashboard')
          }
        }
      
      } else {
        console.log('Not able to authenticate')
          this.$toastr.error('Login Failed','Invalid Credentials',{
            positionClass: 'toast-top-center'
        });
      }
    }
    },
  },
}

export default login
