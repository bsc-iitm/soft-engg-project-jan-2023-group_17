const displaySubject = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
        <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/student/dashboard">Home</router-link></h5></div>

      </div>

      <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Welcome {{ username }}</h3>
      <br>
      <div v-if="message">
        <h5>Subject - {{  subject_list.subject_name  }}</h5>
         <router-link :to="'/student/createTicket/' + subject_list.subject_id"><button type="button" class="btn btn-primary" >Create Ticket</button></router-link>
        </div>
        <br>
         <h6><router-link :to="'/student/viewFAQ/'+subject_list.subject_id">View FAQ</router-link></h6>
        <br>
            
          <div v-if="isTicket">
            <table class="table table-hover caption-top">
            <caption>Ticket Details</caption>
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Timestamp</th>
                  <th scope="col">Title</th>
                  <th scope="col">Status</th>
                  <th scope="col">Number of Likes</th>
                </tr>
              </thead>
              <tbody>
              <tr v-for="(x,index) in ticketList">
                <th scope="row">{{index+1}}</th>
                <td>{{x.timestamp}}</td>
                <td><router-link :to="'/student/viewTicket/' + subject_list.subject_id + '/' + x.ticket_id">{{x.name}}</router-link></td>
                <td>{{x.status}}</td>
                <td>{{x.count}}</td>
              </tr>
              </tbody>
            </table>
            </div>
            <div v-else>
            <br><br>
            <h5 class="text-center"><i>You don't have any tickets to view</i></h5>
            <br><br>
            </div>
      </div>
    </div>

    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        subject_list:[],
        isTicket : false,
        message:'',
        ticketList:[]
      }
    },
    async mounted () {
      document.title = 'Display Subject'
      const res = await fetch(`/api/student/displaySubject/${this.$route.params.id}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      console.log(res)
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.message = data.message
        this.subject_list = data.subject_list
        this.isTicket = data.isTicket
        this.ticketList = data.tickets_list
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      this.$router.push('/student/dashboard')
      }
    },
  
    methods: {
        
    },
  }
  
  export default displaySubject
  