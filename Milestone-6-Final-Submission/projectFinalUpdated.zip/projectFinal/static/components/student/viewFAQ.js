const viewFAQ = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
        <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/student/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
		  <div class="col-sm-6 text-black center-block">
		  	<h3>Welcome {{ username }} </h3>
        <br>
        <div v-if="message != 'None'">
          <div v-for="(faq,index) in faq_list">
                <h6>{{ index+1 }} )</h6> 
                <h6>Question:: {{ faq.faq_title }}</h6> 
                <p>Ans:: <i>{{ faq.faq_ans }} </i></p>   
              </div>
        </div>
        <div v-else>
        <br><br>
        <h5 class="text-center"><i>You don't have any FAQ to view</i></h5>
        <br><br>
        </div>

		  </div>
		</div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        faq_list: [],
        message: ''
      }
    },
    async mounted () {
      document.title = 'FAQList'
      const res = await fetch(`/api/student/viewFAQ/${this.$route.params.id}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      console.log(res)
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.faq_list = data.faq_list
        this.message = data.message
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      }
    },
  
    methods: {

    },

  }
  
  export default viewFAQ