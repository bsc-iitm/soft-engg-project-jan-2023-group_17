const createTicket = {
    template: `
    <section class="vh-100">
    <div class="container-fluid">
      <nav class="navbar navbar-light bg-light">
       <h2>Support System</h2>
        <i>Query your doubts</i>
      </nav>
      <div class="d-flex flex-row-reverse">
        <div class="p-2"><h5><router-link to="/logout">Logout</router-link></h5></div>
        <div class="p-2"><h5><router-link to="/student/dashboard">Home</router-link></h5></div>
      </div>
      <div class="row d-flex justify-content-center">
      <div class="col-sm-6 text-black center-block">
        <h3>Welcome {{ username }} </h3>
      <br>
            <div v-if="message">
              <h5>Add ticket - {{ subject_list.subject_name }}</h5>
            </div>
          <h5>Add your Query</h5>
          <br><br>
          <form action =''>
            <div class="mb-3">
              <label for="ticket_name" class="form-label">Title</label>
               <div class="col-sm-10">
                  <input type="text" class="form-control" id="ticket_name" name="ticket_name" v-model ="ticket_name" required>
              </div>
              </div>

              <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <div class="col-sm-10">
                <textarea class="form-control" id="description" rows="2" name="description" required v-model="description"></textarea>
                </div>
              </div>
                  
            <button type="submit" class="btn btn-primary" @click.prevent="createTicket">Submit</button>
          </form>
      </div>
    </div>
    </div>
  </section>
    `,
  
    data() {
      return {
        username : '',
        ticket_name:'',
        message:'',
        subject_list:[],
        description:''
      }
    },
    async mounted () {
      document.title = 'Create Ticket'
      const res = await fetch(`/api/student/createTicket/${this.$route.params.id}`, {
        headers: {
          'Content-Type': 'application/json',
          'Authentication-Token': localStorage.getItem('auth-token'),
        },
      })
      const data = await res.json()
      console.log(data)
      if (res.ok){
        this.username = data.username
        this.message = data.message
        this.subject_list = data.subject_list
      }
      else{
        this.$toastr.error('ERROR',data.error_message,{
          positionClass: 'toast-top-center'
      });
      this.$router.push('/student/dashboard')
      }
    },
  
    methods: {
          async createTicket(){
            if(this.ticket_name == ''){
                this.$toastr.error('Ticket Title Required','',{
                  positionClass: 'toast-top-center'
              });
              }
              else if(this.description == ''){
                this.$toastr.error('Ticket Description Required','',{
                  positionClass: 'toast-top-center'
              });
              }
              else{
            const res = await fetch(`/api/student/createTicket/${this.$route.params.id}`, {
                method: 'post',
                headers: {
                    'Content-Type': 'application/json',
                    'Authentication-Token': localStorage.getItem('auth-token'),
                  },
                body: JSON.stringify({'ticket_name':this.ticket_name,'description':this.description}),
              })
              console.log(res)
              const data = await res.json()
              console.log(data)
              if (res.ok){
                this.$toastr.success('Ticket Added','',{
                    positionClass: 'toast-top-center'
                });
                this.$router.push('/student/dashboard')
              }
              else{
                console.log(data.error_message)
                  this.$toastr.error('ERROR',data.error_message,{
                  positionClass: 'toast-top-center'
                });
              }
            }
          }

    },
  }
  
  export default createTicket
  