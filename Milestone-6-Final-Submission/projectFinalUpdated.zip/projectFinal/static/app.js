import login from './components/login.js'
import register from './components/register.js'
import adminDashboard from './components/admin/dashboard.js'
import teacherDashboard from './components/teacher/dashboard.js'
import studentDashboard from './components/student/dashboard.js'
import displaySubject from './components/student/displaySubject.js'
import createTicket from './components/student/createTicket.js'
import viewTicket from './components/student/viewTicket.js'
import viewCreatedTicket from './components/student/viewCreatedTicket.js'
import viewFAQ from './components/student/viewFAQ.js'


import viewTeacherTicket from './components/teacher/viewTicket.js'

import adminSubjectView from './components/admin/subjectView.js'
import adminTicketsView from './components/admin/viewTicket.js'
import createFAQ from './components/admin/createFAQ.js'
import listFAQ from './components/admin/listFAQ.js'
import logout from './components/logout.js'
import addsubject from './components/admin/addsubject.js'

const routes = [
  { path: '/', component: login, 
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      (localStorage.getItem('isAuthenticated') == 'true')
    ) {
      if((localStorage.getItem('isType') == 'Admin')){
        next({
        path: '/admin/dashboard',
      })
      return
      }
      else if((localStorage.getItem('isType') == 'Student')){
        next({
        path: '/student/dashboard',
      })
      return
      }
      else{
        next({
        path: '/teacher/dashboard',
      })
      return
      }
      // redirect the user to the login page
      
    }
    else{
      next()
    }
  },
  },
  { path: '/register', component: register },
  { path: '/student/dashboard', component: studentDashboard,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Student')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/student/viewCreatedTicket', component: viewCreatedTicket,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Student')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/student/displaySubject/:id', component: displaySubject,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Student')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/student/viewFAQ/:id', component: viewFAQ,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Student')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/student/createTicket/:id', component: createTicket,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Student')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/student/viewTicket/:subject_id/:ticket_id', component: viewTicket,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Student')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/teacher/dashboard', component: teacherDashboard,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Teacher')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/teacher/viewTicket/:subject_id/:ticket_id', component: viewTeacherTicket,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Teacher')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/admin/dashboard', component: adminDashboard,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Admin')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/admin/viewSubject', component: adminSubjectView,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Admin')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/admin/addsubject', component: addsubject,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Admin')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/admin/listFAQ', component: listFAQ,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Admin')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/admin/viewTicket/:ticket_id', component: adminTicketsView,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Admin')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{ path: '/admin/createFAQ', component: createFAQ,
  beforeEnter: (to, from, next) => {
    console.log(to)
    // reject the navigation
    if (
      // make sure the user is authenticated
      !(localStorage.getItem('isAuthenticated') == 'true' && localStorage.getItem('isType') == 'Admin')
    ) {
      // redirect the user to the login page
      next({
        path: '/',
      })
      return 
    }
    else{
      next()
    }
  },
},
{path:'/logout', component : logout,
beforeEnter: (to, from, next) => {
  console.log(to)
  // reject the navigation
  if (
    // make sure the user is authenticated
    !(localStorage.getItem('isAuthenticated') == 'true')
  ) {
    // redirect the user to the login page
    next({
      path: '/',
    })
    return 
  }
  else{
    next()
  }
},
},
]

const router = new VueRouter({
  routes,
  base: '/',
})


const app = new Vue({
  el: '#app',
  router,
  methods: {
    async logout() {
      const res = await fetch('/logout')
      if (res.ok) {
        localStorage.clear()
        this.$router.push('/')
      } else {
        console.log('could not logout the user')
      }
    },
  },
})
