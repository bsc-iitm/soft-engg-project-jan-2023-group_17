from application.api import RegisterAPI,CheckTypeAPI
from application.api import StudentDashboardAPI,StudentDisplaySubjectAPI,AddTicketAPI,ViewTicketAPI,StudentDisplayCreatedTicketAPI,CloseTicketAPI,ViewFAQAPI
from application.api import TeacherDashboardAPI,ViewTeacherTicketAPI,TeacherFAQAdditionAPI
from application.api import AdminDashboardAPI,AddSubjectAPI,AdminSubjectViewAPI,AdminFAQListAPI,ViewAdminTicketAPI,AdminFAQAddAPI
import os
from flask import Flask
from application import config
from application.config import LocalDevelopmentConfig
from application.database import db
from application.database import login_manager
from flask_restful import Resource, Api
from flask_security import Security, SQLAlchemyUserDatastore
from application.models import Auth,Role
from application.security import user_datastore, sec

app = None
api = None

def create_app():
    app = Flask(__name__, template_folder="templates")
    app.secret_key = 'secret-key'
    if os.getenv('ENV', "development") == "production":
        raise Exception("Currently no production config is setup.")
    else:
        print("Staring Local Development")
        app.config.from_object(LocalDevelopmentConfig)
    # login_manager.init_app(app)
    db.init_app(app)
    sec.init_app(app, user_datastore)
    api = Api(app)
    app.app_context().push()
    app.app_context().push()
    return app, api


app, api = create_app()
'''
@app.before_first_request
def create_db():
     db.create_all()
     db.session.commit()
'''
# Import all the controllers so they are loaded
from application.controllers import *

# Add all restful controllers
api.add_resource(RegisterAPI, "/api/register")
api.add_resource(CheckTypeAPI, "/api/checktype")
api.add_resource(StudentDashboardAPI,"/api/student/dashboard")
api.add_resource(StudentDisplayCreatedTicketAPI,"/api/student/viewCreatedTicket")
api.add_resource(StudentDisplaySubjectAPI,"/api/student/displaySubject/<int:id>")
api.add_resource(ViewFAQAPI,"/api/student/viewFAQ/<int:id>")
api.add_resource(AddTicketAPI,"/api/student/createTicket/<int:id>")
api.add_resource(CloseTicketAPI,"/api/closeTicket/<int:ticket_id>")

api.add_resource(ViewTicketAPI,"/api/student/viewTicket/<int:subject_id>/<int:ticket_id>")

api.add_resource(TeacherDashboardAPI,"/api/teacher/dashboard")
api.add_resource(TeacherFAQAdditionAPI,"/api/teacher/faqAddition")
api.add_resource(ViewTeacherTicketAPI,"/api/teacher/viewTicket/<int:subject_id>/<int:ticket_id>")

api.add_resource(AdminDashboardAPI,"/api/admin/dashboard")
api.add_resource(AdminSubjectViewAPI,"/api/admin/subject")
api.add_resource(AdminFAQListAPI,"/api/admin/listFAQ")
api.add_resource(ViewAdminTicketAPI,"/api/admin/viewTicket/<int:ticket_id>")
api.add_resource(AddSubjectAPI,"/api/addsubject")
api.add_resource(AdminFAQAddAPI,"/api/admin/createFAQ")



if __name__ == '__main__':
    # Run the Flask app
    app.run(host='0.0.0.0', port=8080)
