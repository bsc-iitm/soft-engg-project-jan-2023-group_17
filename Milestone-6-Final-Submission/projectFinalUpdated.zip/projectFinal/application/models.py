from .database import db
from flask_security import UserMixin, RoleMixin


roles_users = db.Table('roles_users',
                       db.Column('user_id', db.Integer(),
                                 db.ForeignKey('auth.user_id')),
                       db.Column('role_id', db.Integer(),
                                 db.ForeignKey('role.id')))


class Auth(UserMixin, db.Model):
    __tablename__ = 'auth'
    user_id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    username = db.Column(db.String, unique=True)
    email = db.Column(db.String, unique=True)
    password = db.Column(db.String, nullable=False)
    active = db.Column(db.Boolean())
    fs_uniquifier = db.Column(db.String(255), unique=True, nullable=False)
    typeOf = db.Column(db.String(255), nullable=False)
    roles = db.relationship('Role', secondary=roles_users,
                            backref=db.backref('users', lazy='dynamic'))

    def get_id(self):
        return (self.user_id)

    def get_username(self):
        return {
            "username":self.username,
            "typeOf":self.typeOf
        }


class Role(db.Model, RoleMixin):
    __tablename__ = 'role'
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))

class Subject(db.Model, RoleMixin):
    __tablename__ = 'subject'
    subject_id = db.Column(db.Integer(), primary_key=True, nullable=False)
    subject_name = db.Column(db.String, nullable=False)

    def obj_to_dict(self):  # for build json format
        return {
            "subject_id": self.subject_id,
            "subject_name": self.subject_name
        }

    def get_subjectId(self):
        return {
            "subject_id":self.subject_id
        }


class StaffSubject(db.Model):
    __tablename__ = 'staff_subject'
    user_id = db.Column(db.Integer, db.ForeignKey(
        "auth.user_id"), primary_key=True, nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey(
        "subject.subject_id"), primary_key=True)

class Ticket(db.Model):
    __tablename__ = 'ticket'
    ticket_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False)
    description = db.Column(db.String,nullable=False)
    status = db.Column(db.String, nullable=False)
    count = db.Column(db.Integer,nullable=False)
    timestamp = db.Column(db.String, nullable=False)
    users_ticket = db.relationship('Auth', secondary="user_ticket")
    subjects_ticket = db.relationship('Subject', secondary="subject_ticket")


    def obj_to_dict(self):  # for build json format
        return {
            "ticket_id": self.ticket_id,
            "name": self.name,
            "description": self.description,
            "status": self.status,
            "count": self.count,
            "timestamp": self.timestamp
        }

    def get_ticketName(self):
        return {
            "name":self.name
        }

class UserTicket(db.Model):
    __tablename__ = 'user_ticket'
    user_id = db.Column(db.Integer, db.ForeignKey(
        "auth.user_id"), primary_key=True, nullable=False)
    ticket_id = db.Column(db.Integer, db.ForeignKey(
        "ticket.ticket_id"), primary_key=True,nullable=False)

class SubjectTicket(db.Model):
    __tablename__ = 'subject_ticket'
    subject_id = db.Column(db.Integer, db.ForeignKey(
        "subject.subject_id"), primary_key=True, nullable=False)
    ticket_id = db.Column(db.Integer, db.ForeignKey(
        "ticket.ticket_id"), primary_key=True,nullable=False)

class UserTicketLike(db.Model):
    __tablename__ = 'user_ticket_like'
    user_id = db.Column(db.Integer, db.ForeignKey(
        "auth.user_id"), primary_key=True, nullable=False)
    ticket_id = db.Column(db.Integer, db.ForeignKey(
        "ticket.ticket_id"), primary_key=True,nullable=False)
    liked = db.Column(db.String, nullable=False)

    def obj_to_dict(self):  # for build json format
        return {
            "user_id": self.user_id,
            "ticket_id": self.ticket_id,
            "liked": self.liked
        }

class Comment(db.Model):
    __tablename__ = 'comment'
    comment_id = db.Column(db.Integer, primary_key=True, nullable=False)
    comment_desc = db.Column(db.String, nullable=False)
    timestamp = db.Column(db.String, nullable=False)
    ticket_comment = db.relationship('Ticket', secondary="ticket_comment")
    user_comment = db.relationship('Auth', secondary="user_comment")

    def obj_to_dict(self):  # for build json format
        return {
            "comment_id": self.comment_id,
            "comment_desc": self.comment_desc,
            "timestamp": self.timestamp
        }

class TicketComment(db.Model):
    __tablename__ = 'ticket_comment'
    ticket_id = db.Column(db.Integer, db.ForeignKey(
        "ticket.ticket_id"), primary_key=True, nullable=False)
    comment_id = db.Column(db.Integer, db.ForeignKey(
        "comment.comment_id"), primary_key=True,nullable=False)

class UserComment(db.Model):
    __tablename__ = 'user_comment'
    comment_id = db.Column(db.Integer, db.ForeignKey(
        "comment.comment_id"), primary_key=True,nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey(
        "auth.user_id"), primary_key=True,nullable=False)

    def obj_to_dict(self):  # for build json format
        return {
            "comment_id": self.comment_id,
            "user_id": self.user_id,
        }

class TicketFAQ(db.Model):
    __tablename__ = 'ticket_faq'
    ticket_id = db.Column(db.Integer, db.ForeignKey(
        "ticket.ticket_id"), primary_key=True,nullable=False)
    faq_added = db.Column(db.String, nullable=False)

    def obj_to_dict(self):  # for build json format
        return {
            "ticket_id": self.ticket_id,
        }    

class FAQ(db.Model):
    __tablename__ = 'faq'
    faq_id = db.Column(db.Integer, primary_key=True, nullable=False)
    faq_title = db.Column(db.String, nullable=False)
    faq_ans = db.Column(db.String, nullable=False)
    faq_subject = db.relationship('Subject', secondary="faq_subject")


    def obj_to_dict(self):  # for build json format
        return {
            "faq_id": self.faq_id,
            "faq_title": self.faq_title,
            "faq_ans": self.faq_ans
        }

class FAQSubject(db.Model):
    __tablename__ = 'faq_subject'
    faq_id = db.Column(db.Integer, db.ForeignKey(
        "faq.faq_id"), primary_key=True, nullable=False)
    subject_id = db.Column(db.Integer, db.ForeignKey(
        "subject.subject_id"), primary_key=True,nullable=False)
