from flask_security import Security, SQLAlchemyUserDatastore
from application.models import db, Auth, Role

user_datastore = SQLAlchemyUserDatastore(db, Auth, Role)
sec = Security()
