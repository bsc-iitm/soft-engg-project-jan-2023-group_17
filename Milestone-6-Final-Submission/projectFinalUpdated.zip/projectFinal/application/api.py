from flask_restful import Resource
from flask_restful import fields, marshal_with
from flask_restful import reqparse
from application.validation import BusinessValidationError
from application.models import Auth, StaffSubject,Subject,Ticket,UserTicket,SubjectTicket,UserTicketLike,Comment,TicketComment,UserComment,TicketFAQ,FAQ,FAQSubject
from application.database import db
from flask import send_file
from flask_security import hash_password, current_user, auth_required
from application.security import user_datastore
from datetime import datetime


create_register_parser = reqparse.RequestParser()
create_register_parser.add_argument('username')
create_register_parser.add_argument('email')
create_register_parser.add_argument('password')
create_register_parser.add_argument('registerType')
create_register_parser.add_argument('subject_id')

add_subject_parser = reqparse.RequestParser()
add_subject_parser.add_argument('subject_name')

add_ticket_parse = reqparse.RequestParser()
add_ticket_parse.add_argument('ticket_name')
add_ticket_parse.add_argument('description')

add_like_parse = reqparse.RequestParser()
add_like_parse.add_argument('liked')
add_like_parse.add_argument('comment')
add_like_parse.add_argument('status')


add_comment_parse = reqparse.RequestParser()
add_comment_parse.add_argument('comment')

close_ticket_parse = reqparse.RequestParser()
close_ticket_parse.add_argument('status')

add_to_faq_list = reqparse.RequestParser()
add_to_faq_list.add_argument('ticket_id')

create_faq_list = reqparse.RequestParser()
create_faq_list.add_argument('faq_title')
create_faq_list.add_argument('faq_ans')
create_faq_list.add_argument('subject_id')


resource_fields = {
    'user_id':   fields.Integer,
    'username':    fields.String,
    'email':    fields.String,
}


class RegisterAPI(Resource):
    def dict_helper(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    def get(self):
        subject_list = Subject.query.all()
        print(subject_list)
        if subject_list is None or len(subject_list) == 0:
            msg = None
            return {'message':'None'}
        else:
            msg = "Subjects Present"
            subject_list_dict = RegisterAPI.dict_helper(subject_list)
            return {'message': msg, 'subject_list': subject_list_dict}

    @marshal_with(resource_fields)
    def post(self):
        args = create_register_parser.parse_args()
        username = args.get("username", None)
        email = args.get("email", None)
        password = args.get("password", None)
        registerType = args.get("registerType", None)
        subject_id = args.get("subject_id", None)
        if username is None or len(username) == 0:
            raise BusinessValidationError(
                status_code=400, error_code="BE1001", error_message="username is required")
        if email is None or len(email) == 0:
            raise BusinessValidationError(
                status_code=400, error_code="BE1002", error_message="email is required")
        if password is None or len(password) == 0:
            raise BusinessValidationError(
                status_code=400, error_code="BE1003", error_message="password is required")
        if registerType is None or len(registerType) == 0:
            raise BusinessValidationError(
                status_code=400, error_code="BE1004", error_message="type is required")
        if registerType == 'Lecturer' and (subject_id is None or len(subject_id) == 0):
            raise BusinessValidationError(
                status_code=400, error_code="BE1011", error_message="Subject Name is required")
        if "@" in email:
            pass
        else:
            raise BusinessValidationError(
                status_code=400, error_code="BE1005", error_message="Invalid email")
        existing_user = Auth.query.filter_by(username=username).first()
        if existing_user is None:
            existing_email = Auth.query.filter_by(email=email).first()
            if existing_email is None:
                try:
                    user = user_datastore.create_user(
                        username=username, email=email, password=hash_password(password),typeOf=registerType)
                    user.role = 'Admin'
                    user.active = True
                    db.session.add(user)
                    db.session.commit()
                    print('Successfully registered')
                    if(registerType == 'Lecturer'):
                        current_user = Auth.query.filter_by(username=username).first()
                        staff_subject = StaffSubject(user_id=current_user.user_id,subject_id=subject_id)
                        db.session.add(staff_subject)
                        db.session.commit()
                        print('Successfully registered Teacher with subject')
                    return user
                except Exception as e:
                    print('Error occured while registering:::', e)
                    raise BusinessValidationError(
                        status_code=400, error_code="BE1006", error_message="Error while registering user")
            else:
                print('Email exists')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1007", error_message="Email Id already exists")
        else:
            print('Username exists')
            raise BusinessValidationError(
                status_code=403, error_code="BE1008", error_message="Username already exists")

class CheckTypeAPI(Resource):
    
    @auth_required('token')
    def get(self):
        print(current_user.typeOf)
        print(current_user.user_id, current_user.username)
        if(current_user):
            msg = None
            return {'username': current_user.username , 'typeOf': current_user.typeOf}
        else:
            return {'Authorization': 'Not Authorized'}

class StudentDashboardAPI(Resource):
    def dict_helper(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            msg = None
            subject_list = Subject.query.all()
            print(subject_list)
            if subject_list is None or len(subject_list) == 0:
                msg = None
            else:
                msg = "Subjects Present"
                subject_list_dict = StudentDashboardAPI.dict_helper(subject_list)
            return {'username': current_user.username,'message': msg, 'subject_list': subject_list_dict}
        else:
            return {'Authorization': 'Not Authorized'}

class StudentDisplaySubjectAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self,id=None):
        print(current_user.user_id, current_user.username)
        if(current_user):
            isTicket=False
            subject_list = Subject.query.filter_by(subject_id=id).first()
            if subject_list is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            subject_list_dict = StudentDisplaySubjectAPI.dict_helper(subject_list)
            tickets = Ticket.query.join(SubjectTicket).filter_by(
            subject_id=id).order_by(db.text('timestamp asc')).all()
            tickets_list_dict = None
            if tickets:
                isTicket=True
            if len(tickets) > 1:
                tickets_list_dict = StudentDisplaySubjectAPI.dict_helperList(tickets)
            elif len(tickets) == 1:
                tickets_list_dict = StudentDisplaySubjectAPI.dict_helper(tickets[0])
            return {'username': current_user.username,'subject_list': subject_list_dict[0],'tickets_list': tickets_list_dict,'isTicket': isTicket, 'message':'Subject Present'}
        else:
            return {'Authorization': 'Not Authorized'}

class AdminDashboardAPI(Resource):
    def dict_helper(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            msg = None
            subject_list = Subject.query.all()
            print(subject_list)
            if subject_list is None or len(subject_list) == 0:
                msg = None
                return {'username': current_user.username,'message': msg, 'subject_list_len': None}
            else:
                msg = "Subjects Present"
                countOfTickets = Ticket.query.count()
                closedTicket = Ticket.query.filter_by(status='closed').count()
                faqCount = TicketFAQ.query.count()
                return {'username': current_user.username,'message': msg, 'subject_list_len': len(subject_list), 'countOfTickets':countOfTickets, 'closedTicket':closedTicket,'faqCount':faqCount}
        else:
            return {'Authorization': 'Not Authorized'}

class TeacherDashboardAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            isTicket=False
            subjectList = Subject.query.join(StaffSubject).filter_by(
            user_id=current_user.user_id).first()
            if subjectList is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1012", error_message="PAGE NOT FOUND")
            subject_list_dict = TeacherDashboardAPI.dict_helper(subjectList)
            tickets = Ticket.query.join(SubjectTicket).filter_by(
            subject_id=subject_list_dict[0].get('subject_id')).order_by(db.text('timestamp asc')).all()
            tickets_list_dict = None
            if tickets:
                isTicket=True
                if len(tickets) > 1:
                    tickets_list_dict = TeacherDashboardAPI.dict_helperList(tickets)
                elif len(tickets) == 1:
                    tickets_list_dict = TeacherDashboardAPI.dict_helper(tickets[0])
            print(tickets)
            if tickets_list_dict:
                for ticket in tickets_list_dict:
                    ticketList = TicketFAQ.query.filter_by(ticket_id=ticket.get('ticket_id')).first()
                    if ticketList:
                        ticket['addedToFAQ'] = True
                    else:
                        ticket['addedToFAQ'] = False
            return {'username': current_user.username,'subject_list':subject_list_dict,'tickets_list': tickets_list_dict,'isTicket': isTicket,'message':'Subject Present'}
        else:
            return {'Authorization': 'Not Authorized'}

class AdminSubjectViewAPI(Resource):
    def dict_helper(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            msg = None
            subject_list = Subject.query.all()
            print(subject_list)
            if subject_list is None or len(subject_list) == 0:
                msg = None
            else:
                msg = "Subjects Present"
                subject_list_dict = AdminSubjectViewAPI.dict_helper(subject_list)
            return {'username': current_user.username,'message': msg, 'subject_list': subject_list_dict}
        else:
            return {'Authorization': 'Not Authorized'}

class AddSubjectAPI(Resource):
    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            return {'username': current_user.username}
        else:
            return {'Authorization': 'Not Authorized'}

    @auth_required('token')
    def post(self):
        args = add_subject_parser.parse_args()
        subject_name = args.get("subject_name", None)
        print(subject_name)
        existing_subject_name = Subject.query.filter_by(subject_name=subject_name).first()
        if existing_subject_name is None:
            try:
                addSubject = Subject(subject_name=subject_name)
                db.session.add(addSubject)
                db.session.commit()  # create new subject
                print('Subject added successfully')
                return {'Event': 'Subject added successfully'}
            except Exception as e:
                print('Error occured while adding subject:::', e)
                raise BusinessValidationError(
                    status_code=403, error_code="BE1009", error_message="Error occured while adding subject")
        else:
            raise BusinessValidationError(
                            status_code=403, error_code="BE1010", error_message="Subject Name already exist")


class AddTicketAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    @auth_required('token')
    def get(self,id=None):
        print(current_user.user_id, current_user.username)
        if(current_user):
            subject_list = Subject.query.filter_by(subject_id=id).first()
            if subject_list is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            subject_list_dict = AddTicketAPI.dict_helper(subject_list)
            return {'username': current_user.username,'subject_list': subject_list_dict[0],'message':'Subject Present'}
        else:
            return {'Authorization': 'Not Authorized'}

    @auth_required('token')
    def post(self,id=None):
        args = add_ticket_parse.parse_args()
        name = args.get("ticket_name", None)
        description = args.get("description", None)
        status = 'Response Pending'
        count=0
        timestamp= datetime.now().strftime('%Y-%m-%dT%H:%M')
        subjectList = Subject.query.filter_by(
            subject_id=id).first()
        try:
            addTickets = Ticket(name=name, description=description,
                              status=status,count=count,timestamp=timestamp)
            addTickets.users_ticket.append(current_user)
            db.session.add(addTickets)
            addTickets.subjects_ticket.append(subjectList)
            db.session.commit()  # create new tickets
            return {'Event': 'Ticket created successfully'}
        except Exception as e:
            print('Error occured while adding tickets:::', e)
            raise BusinessValidationError(
                status_code=403, error_code="BE1015", error_message="Error occured while adding events")

class ViewTicketAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self,subject_id=None,ticket_id=None):
        print(current_user.user_id, current_user.username)
        if(current_user):
            enableComment=False
            alreadyLiked=False
            subject_list = Subject.query.filter_by(subject_id=subject_id).first()
            if subject_list is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            subject_list_dict = ViewTicketAPI.dict_helper(subject_list)
            tickets = Ticket.query.join(SubjectTicket).filter_by(
            subject_id=subject_id,ticket_id=ticket_id).first()
            ticket_user = Ticket.query.join(UserTicket).filter_by(ticket_id=ticket_id,user_id=current_user.user_id).first()
            user_ticket_like = UserTicketLike.query.filter_by(ticket_id=ticket_id,user_id=current_user.user_id).first()
            ticket_comment = Comment.query.join(TicketComment).filter_by(ticket_id=ticket_id).order_by(db.text('timestamp asc')).all()
            ticket_comment_dict = None
            if ticket_comment is not None:
                if len(ticket_comment) > 1:
                    ticket_comment_dict = ViewTicketAPI.dict_helperList(ticket_comment)
                elif len(ticket_comment) == 1:
                    ticket_comment_dict = ViewTicketAPI.dict_helper(ticket_comment[0])
            if user_ticket_like:
                alreadyLiked=True
            if ticket_user:
                enableComment=True
            if tickets is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            tickets_list_dict = ViewTicketAPI.dict_helper(tickets)
            print(ticket_comment_dict)
            if ticket_comment_dict:
                for comment in ticket_comment_dict:
                    user_name = Auth.query.join(UserComment).filter_by(comment_id=comment.get('comment_id')).first().get_username()
                    comment['user_name'] = user_name['username']
                    comment['user_type'] = user_name['typeOf']
            return {'username': current_user.username,'subject_list': subject_list_dict[0],'message':'Subject Present','ticket_list':tickets_list_dict[0], 'enableComment':enableComment,'alreadyLiked':alreadyLiked,'comments':ticket_comment_dict}
        else:
            return {'Authorization': 'Not Authorized'}


    @auth_required('token')
    def post(self,subject_id=None,ticket_id=None):
        args = add_like_parse.parse_args()
        liked = args.get("liked", None)
        print(liked)
        updateCount=0
        if liked == 'no':
            try:
                ticketList = Ticket.query.filter_by(ticket_id=ticket_id).first()
                userTicketLike = UserTicketLike.query.filter_by(ticket_id=ticket_id,user_id=current_user.user_id).first()
                if userTicketLike is None:
                    addUserTicketLike = UserTicketLike(ticket_id=ticket_id,user_id=current_user.user_id,liked='Yes')
                    db.session.add(addUserTicketLike)
                    db.session.commit()  # added entry in Like
                    print('Like added successfully')
                updateCount = ticketList.count + 1
                Ticket.query.filter_by(ticket_id=ticket_id).update({'count': updateCount})
                db.session.commit()  # updated count
                print('Successfully updated counts')
                return {'Event': 'Event Updated successfully'}
            except Exception as e:
                print('Error occured while writing count:::', e)
                raise BusinessValidationError(
                    status_code=403, error_code="BE1020", error_message="Error occured while updating events")
        elif liked == 'yes':
            try:
                ticketList = Ticket.query.filter_by(ticket_id=ticket_id).first()
                userTicketLike = UserTicketLike.query.filter_by(ticket_id=ticket_id,user_id=current_user.user_id).first()
                if userTicketLike:
                    db.session.delete(userTicketLike)
                    db.session.commit()  # remove entry in Like
                    print('Like removed successfully')
                updateCount = ticketList.count - 1
                Ticket.query.filter_by(ticket_id=ticket_id).update({'count': updateCount})
                db.session.commit()  # updated count
                print('Successfully updated counts')
                return {'Event': 'Event Updated successfully'}
            except Exception as e:
                print('Error occured while writing count:::', e)
                raise BusinessValidationError(
                    status_code=403, error_code="BE1020", error_message="Error occured while updating events")

        comment = args.get("comment",None)
        status = args.get("status",None)
        timestamp= datetime.now().strftime('%Y-%m-%dT%H:%M')
        if comment:
            try:
                addComment = Comment(comment_desc=comment,timestamp=timestamp)
                ticketList = Ticket.query.filter_by(ticket_id=ticket_id).first()
                addComment.ticket_comment.append(ticketList)
                addComment.user_comment.append(current_user)
                db.session.add(addComment)
                db.session.commit()  # create new comments
                if status == 'Response Pending':
                    Ticket.query.filter_by(ticket_id=ticket_id).update({'status':status})
                    db.session.commit()  # Status Updated
                print('Created comments with userid')
                return {'Event': 'Event Updated successfully'}
            except Exception as e:
                print('Error occured while writing comments:::', e)
                raise BusinessValidationError(
                    status_code=403, error_code="BE1020", error_message="Error occured while updating events")



class ViewTeacherTicketAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self,subject_id=None,ticket_id=None):
        print(current_user.user_id, current_user.username)
        if(current_user):
            enableComment=True
            subject_list = Subject.query.filter_by(subject_id=subject_id).first()
            if subject_list is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            subject_list_dict = ViewTeacherTicketAPI.dict_helper(subject_list)
            tickets = Ticket.query.join(SubjectTicket).filter_by(
            subject_id=subject_id,ticket_id=ticket_id).first()
            if tickets is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            tickets_list_dict = ViewTicketAPI.dict_helper(tickets)
            ticket_comment = Comment.query.join(TicketComment).filter_by(ticket_id=ticket_id).order_by(db.text('timestamp asc')).all()
            ticket_comment_dict = None
            if ticket_comment is not None:
                if len(ticket_comment) > 1:
                    ticket_comment_dict = ViewTeacherTicketAPI.dict_helperList(ticket_comment)
                elif len(ticket_comment) == 1:
                    ticket_comment_dict = ViewTeacherTicketAPI.dict_helper(ticket_comment[0])
            if ticket_comment_dict:
                for comment in ticket_comment_dict:
                    user_name = Auth.query.join(UserComment).filter_by(comment_id=comment.get('comment_id')).first().get_username()
                    comment['user_name'] = user_name['username']
                    comment['user_type'] = user_name['typeOf']
            return {'username': current_user.username,'subject_list': subject_list_dict[0],'message':'Subject Present','ticket_list':tickets_list_dict[0], 'enableComment':enableComment,'comments':ticket_comment_dict}
        else:
            return {'Authorization': 'Not Authorized'}

    @auth_required('token')
    def post(self,subject_id=None,ticket_id=None):
        args = add_comment_parse.parse_args()
        comment = args.get("comment", None)
        timestamp= datetime.now().strftime('%Y-%m-%dT%H:%M')
        try:
            status = 'Responded'
            addComment = Comment(comment_desc=comment,timestamp=timestamp)
            ticketList = Ticket.query.filter_by(ticket_id=ticket_id).first()
            addComment.ticket_comment.append(ticketList)
            addComment.user_comment.append(current_user)
            db.session.add(addComment)
            db.session.commit()  # create new comments
            Ticket.query.filter_by(ticket_id=ticket_id).update({'status':status})
            db.session.commit()  # Status Updated
            print('Created comments with userid')
            return {'Event': 'Event Updated successfully'}
        except Exception as e:
            print('Error occured while writing comments:::', e)
            raise BusinessValidationError(
                status_code=403, error_code="BE1020", error_message="Error occured while updating events")


class StudentDisplayCreatedTicketAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            isTicket=False
            ticket_list = Ticket.query.join(UserTicket).filter_by(user_id=current_user.user_id).order_by(db.text('timestamp asc')).all()
            if ticket_list is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            tickets_list_dict = None
            if ticket_list:
                isTicket=True
            if len(ticket_list) > 1:
                tickets_list_dict = StudentDisplayCreatedTicketAPI.dict_helperList(ticket_list)
            elif len(ticket_list) == 1:
                tickets_list_dict = StudentDisplayCreatedTicketAPI.dict_helper(ticket_list[0])
            for ticket in tickets_list_dict:
                subject = Subject.query.join(SubjectTicket).filter_by(ticket_id=ticket.get('ticket_id')).first().get_subjectId()
                ticket['subject_id'] = subject['subject_id']
            return {'username': current_user.username,'tickets_list': tickets_list_dict,'isTicket': isTicket}
        else:
            return {'Authorization': 'Not Authorized'}


class CloseTicketAPI(Resource):

    @auth_required('token')
    def post(self,ticket_id=None):
        args = close_ticket_parse.parse_args()
        status = args.get("status", None)
        try:
            if status:
                Ticket.query.filter_by(ticket_id=ticket_id).update({'status':status})
                db.session.commit()  # Status Updated
                print('Closed the ticket')
            return {'Event': 'Event Updated successfully'}
        except Exception as e:
            print('Error occured while closing ticket:::', e)
            raise BusinessValidationError(
                status_code=403, error_code="BE1020", error_message="Error occured while updating events")

class TeacherFAQAdditionAPI(Resource):
    
    @auth_required('token')
    def post(self):
        args = add_to_faq_list.parse_args()
        ticket_id = args.get("ticket_id", None)
        try:
            if ticket_id:
                ticketList = TicketFAQ(ticket_id=ticket_id,faq_added='Yes')
                db.session.add(ticketList)
                db.session.commit()  # added to faq
                print('Ticket added to FAQList')
                return {'Event': 'FAQ Event added successfully'}
        except Exception as e:
            print('Error occured while writing faq:::', e)
            raise BusinessValidationError(
                status_code=403, error_code="BE1020", error_message="Error occured while updating events")

class AdminFAQListAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            msg = None
            faq_list = TicketFAQ.query.all()
            print(faq_list)
            faq_list_dict=None
            if faq_list is None or len(faq_list) == 0:
                msg = None
                return {'username': current_user.username,'message': msg, 'faq_list_dict': None}
            else:
                msg = "FAQ Present"
                if len(faq_list) > 1:
                    faq_list_dict = AdminFAQListAPI.dict_helperList(faq_list)
                elif len(ticket_list) == 1:
                    faq_list_dict = AdminFAQListAPI.dict_helper(faq_list[0])
                for faq in faq_list_dict:
                    ticketName = Ticket.query.filter_by(ticket_id=faq.get('ticket_id')).first().get_ticketName()
                    faq['ticketName'] = ticketName['name']
                return {'username': current_user.username,'message': msg, 'faq_list_dict': faq_list_dict}
        else:
            return {'Authorization': 'Not Authorized'}


class ViewAdminTicketAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self,ticket_id=None):
        print(current_user.user_id, current_user.username)
        if(current_user):
            tickets = Ticket.query.join(SubjectTicket).filter_by(ticket_id=ticket_id).first()
            if tickets is None:
                print('Requested page not found')
                raise BusinessValidationError(
                    status_code=403, error_code="BE1013", error_message="PAGE NOT FOUND")
            subjectList = tickets.subjects_ticket
            subject_dict = subjectList[0].obj_to_dict()
            tickets_list_dict = ViewAdminTicketAPI.dict_helper(tickets)
            tickets_list_dict[0]['subject_id'] = subject_dict.get('subject_id')
            tickets_list_dict[0]['subject_name'] = subject_dict.get('subject_name')
            print(tickets_list_dict)
            ticket_comment = Comment.query.join(TicketComment).filter_by(ticket_id=ticket_id).order_by(db.text('timestamp asc')).all()
            ticket_comment_dict = None
            if ticket_comment is not None:
                if len(ticket_comment) > 1:
                    ticket_comment_dict = ViewAdminTicketAPI.dict_helperList(ticket_comment)
                elif len(ticket_comment) == 1:
                    ticket_comment_dict = ViewAdminTicketAPI.dict_helper(ticket_comment[0])
            if ticket_comment_dict:
                for comment in ticket_comment_dict:
                    user_name = Auth.query.join(UserComment).filter_by(comment_id=comment.get('comment_id')).first().get_username()
                    comment['user_name'] = user_name['username']
                    comment['user_type'] = user_name['typeOf']
            return {'username': current_user.username,'message':'Subject Present','ticket_list':tickets_list_dict,'comments':ticket_comment_dict}
        else:
            return {'Authorization': 'Not Authorized'}

class AdminFAQAddAPI(Resource):
    def dict_helper(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self):
        print(current_user.user_id, current_user.username)
        if(current_user):
            subject_list = Subject.query.all()
            if subject_list is None or len(subject_list) == 0:
                return {'username': current_user.username,'message':'None'}
            else:
                msg = "Subjects Present"
                subject_list_dict = AdminFAQAddAPI.dict_helper(subject_list)
                return {'username': current_user.username,'message': msg, 'subject_list': subject_list_dict}
        else:
            return {'Authorization': 'Not Authorized'}

    @auth_required('token')
    def post(self):
        args = create_faq_list.parse_args()
        faq_title = args.get("faq_title", None)
        faq_ans = args.get("faq_ans", None)
        subject_id = args.get("subject_id", None)
        print(faq_title,faq_ans,subject_id)
        try:
            subjectList = Subject.query.filter_by(subject_id=subject_id).first()
            faq_list = FAQ(faq_title=faq_title,faq_ans=faq_ans)
            db.session.add(faq_list)
            faq_list.faq_subject.append(subjectList)
            db.session.commit() #FAQ Added
            print('FAQ Added')
            return {'Event': 'FAQ added successfully'}
        except Exception as e:
            print('Error occured while adding faq:::', e)
            raise BusinessValidationError(
                status_code=403, error_code="BE1020", error_message="Error occured while updating faq")

class ViewFAQAPI(Resource):
    def dict_helper(objlist):
        result2 = [objlist.obj_to_dict()]
        return result2

    def dict_helperList(objlist):
        result2 = [item.obj_to_dict() for item in objlist]
        return result2

    @auth_required('token')
    def get(self,id):
        print(current_user.user_id, current_user.username)
        if(current_user):
            faq_list = FAQ.query.join(FAQSubject).filter_by(subject_id=id).all()
            if faq_list is None or len(faq_list) == 0:
                return {'username': current_user.username,'message':'None'}
            else:
                msg = "FAQ Present"
                if len(faq_list) > 1:
                    faq_list_dict = ViewFAQAPI.dict_helperList(faq_list)
                elif len(faq_list) == 1:
                    faq_list_dict = ViewFAQAPI.dict_helper(faq_list[0])
                return {'username': current_user.username,'message': msg, 'faq_list': faq_list_dict}
        else:
            return {'Authorization': 'Not Authorized'}
