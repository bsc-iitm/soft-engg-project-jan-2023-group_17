Windows
1) Create virtual environment::
	1. create folder env
	2. python -m venv ./env
		#Activate virtual env
		Execute Scripts\activate.bat

2) Installing Requirements::
	pip install -r requirements.txt

3) Execute ::
	python main.py
4) Login and experience Query app